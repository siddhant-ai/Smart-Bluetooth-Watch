# SmartwatchAndroidApp
The entire Android App used to communicate with my smartwatch via Bluetooth.
