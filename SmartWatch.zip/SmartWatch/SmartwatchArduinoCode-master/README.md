# SmartwatchArduinoCode
The Arduino code powering my smartwatch build.

Dependencies are: -Adafruit_GFX.h
                  -Adafruit_SSD1306.h
